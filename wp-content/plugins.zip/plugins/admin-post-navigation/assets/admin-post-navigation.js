jQuery(document).ready(function($) {
	$('#admin-post-nav').appendTo($('#wpbody-content .wrap:first ' + c2c_apn.tag + ':first'));
	$('#adminpostnav, label[for="adminpostnav-hide"]').hide();
});

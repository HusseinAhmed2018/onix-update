<?php
/* #04ACFF
 * Template Name: About Page Template
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

get_header();
the_post();
?>

 				<div class="site-con">
					<div class="container sm">
						<div class="site-co">
							<h2><?=the_title() ; ?></h2>
							<div class="prods">
								<img src="images/gallery/processing.jpg">
								<p>
									In 2009, onix started the operations in Badr Factory; we used our latest technological industry machinery that includes:
								</p>
								<p>
									<strong>• 4 Gang Saws</strong><br>
									<strong>• 1 Block Cutters</strong><br>
									<strong>• 4 Bridge Cutters</strong><br>
									<strong>• Polishing Lines with Polyester and Epoxy Treatment</strong><br>
									<strong>• Brushing lines</strong><br>
									<strong>• 3 Tumbling machine</strong><br>

								</p>
								<p>
									These technological machinery is used to finalize the marble construction of Badr factory.

									Badr Factory will boost the production capacity 30,000 m2/month by working on a two-shift basis; each shift is for 8 hours.

									The epoxy line will be the Group’s main market differentiator, with a production capacity of 30,000m2/month. The epoxy finish is the highest quality stone treatment that can utilize low quality blocks to produce high quality, value added products.

								</p>

							</div>
						</div>
					</div>
				</div>
    
<?php get_footer(); ?>

<?php
/*
 * Template Name:  material Page Template
 *
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

require_once('taxonomy-material.php')
?>
